﻿using log4myself;
using log4net;
using log4net.Layout;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace log2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();


            //***************************************************************
            //读取配置文件的信息
            log1 = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
            
            //设置textbox打印日志
            var logPattern = "%d{yyyy-MM-dd HH:mm:ss} --%-5p-- %m%n";
            var textBox_logAppender = new TextBoxBaseAppender()
            {
                TextBox = this.textBox1,//注释后 就只有文件log
                Layout = new PatternLayout(logPattern)
            };
            //相当于root标签下的   <appender-ref ref="LogFile" />
            log4net.Config.BasicConfigurator.Configure(textBox_logAppender);

            //设置listview打印日志
            var list_logAppender = new ListViewBaseAppender()
            {
                listView = this.listView1,//注释后 就只有文件log
                Layout = new PatternLayout(logPattern)
            };
            log4net.Config.BasicConfigurator.Configure(list_logAppender);
        }

        ILog log1;

        private void button1_Click(object sender, EventArgs e)
        {


            log1.Error("测试");
            log1.Info("正常运行");
        }
    }
}
