﻿
using log4net;
using log4net.Config;
using log4net.Layout;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace GOlog
{
    public partial class Form1 : Form
    {
        ILog log1 = LogManager.GetLogger(typeof(Form1));
        public Form1()
        {
            InitializeComponent();
            //打印日志格式
            var logPattern = "%date [%thread] %logger %L(line) %method  %-5level %message%newline";
            ////设置textbox打印日志
            //var textBox_logAppender = new TextBoxBaseAppender()
            //{
            //    TextBox = this.textBox1,//注释后 就只有文件log
            //    Layout = new PatternLayout(logPattern)
            //};
            ////相当于root标签下的   <appender-ref ref="LogFile" />
            //log4net.Config.BasicConfigurator.Configure(textBox_logAppender);
            //设置listview打印日志
            var list_logAppender = new ListViewBaseAppender()
            {
                listView = this.listView1,//注释后 就只有文件log
                Layout = new PatternLayout(logPattern)
            };
            log4net.Config.BasicConfigurator.Configure(list_logAppender);
        }
        //  ***********************************log4net相关说明
        //          //  创建日志记录组件实例
        //            ILog log = log4net.LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
        //            ILog log = log4net.LogManager.GetLogger("视觉程序");
        //            ILog log = log4net.LogManager.GetLogger(typeof(Form1));//Form1是当前类的名字
        //            MessageBox.Show(log.ToString() + "log.Logger.Name = " + log.Logger.Name);
        //            //记录错误日志
        //              log.Error("error", new Exception("在这里发生了一个异常,Error Number:" + random.Next()));
        ////记录严重错误
        //            log.Fatal("fatal", new Exception("在发生了一个致命错误，Exception Id：" + random.Next()));
        //           // 记录一般信息
        //             log.Info("提示：系统正在运行");
        //            //记录调试信息
        //              log.Debug("调试信息：debug");
        //            //记录警告信息
        //              log.Warn("警告：warn");
        // BasicConfigurator.Configure();//无法输出打印日志的时候加这句试试看
        //      *******************使用说明先在类第一句创建记录组件，后面就可以使用了**************************
        //
        //          //  创建日志记录组件实例
        //            ILog log = log4net.LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
        //            ILog log = log4net.LogManager.GetLogger("视觉程序");
        //            ILog log = log4net.LogManager.GetLogger(typeof(Form1));//Form1是当前类的名字
        //log1.Error("测试");
        //log1.Info("正常运行");
        //log1.Error("error", new Exception("在这里发生了一个异常"));
        ////记录严重错误
        //log1.Fatal("fatal", new Exception("在发生了一个致命错误"));
        //// 记录一般信息
        //log1.Info("提示：系统正在运行");
        ////记录调试信息
        //log1.Debug("调试信息：debug");
        ////记录警告信息
        //log1.Warn("警告：warn");
        private void button1_Click(object sender, EventArgs e)
        {
            BasicConfigurator.Configure();
            log1.Error("测试");
            log1.Info("正常运行");
            log1.Error("error", new Exception("在这里发生了一个异常"));
            //记录严重错误
            log1.Fatal("fatal", new Exception("在发生了一个致命错误"));
            // 记录一般信息
            log1.Info("提示：系统正在运行");
            //记录调试信息
            log1.Debug("调试信息：debug");
            //记录警告信息
            log1.Warn("警告：warn");
   
        }
        private void Form1_Load(object sender, EventArgs e)
        {
        }
        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
        }
    }
}
